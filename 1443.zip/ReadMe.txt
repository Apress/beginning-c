I created all the files under Microsoft Windows so lines are terminated by CR/LF.

In addition to this "ReadMe" file you'll find two zip archives in the primary archive, so you'll need to unzip each of these into a directory of your choice to get at the code.

The code from the chapters in the book are in the archive "2530 Source Code from the Book.zip".
The solutions to the exercises are in the archive 2530 Exercise Solutions.zip".

The archives containing the code from the book and solutions to the exercises are organized by chapter. When you unzip an archive, you will find all the code corresponding to a given chapter stored in a single directory.

Note that my solutions to the exercises are not the only ones possible or even the best solutions. If your solution to an exercise is different, it doesn't mean that it is wrong. As long as it works it is OK. You may well be able to come up with better solutions that the ones in the archive!
Have fun!

Ivor Horton

